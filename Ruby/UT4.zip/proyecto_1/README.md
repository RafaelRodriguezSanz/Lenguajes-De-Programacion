# Execute

To execute the code use:

```
rake run
```

To execute tests use:

```
rake test
```
