# Execute

To execute the code use:

```
rake run
```
