module Main where

import AllEquals
import Json
import SchemyInterpreter
import Data.List.Split

main :: IO ()
main = do
    --putStrLn "Please, enter csv a csv list of values:"
    --input <- getLine
    --if input == "exit"
    --    then putStrLn "Hasta la vista, Baby! 😎"
    --    else do
    --        let valores = splitOn "," input
    --        let resultado = if allEqual valores then "They are all equals" else "They are not all equals"
    --        putStrLn ("Result: " ++ resultado)
    --        main
    --let crearObjeto = JSONObject
    --        [ ("id", JSONNumber 123),
    --        ("value", JSONString "admin")
    --        ]
    --putStrLn (show crearObjeto)
    
        let exp1 = SchemyAdd (SchemyNumber 2.0) (SchemyNumber 3.0)
        let exp2 = SchemyMult exp1 (SchemyNumber 4.0)
        putStrLn ("Expresión 1:" ++ show exp1)
        putStrLn ("Expresión 2:" ++ show exp2)

        let result = eval exp2
        putStrLn $ "Resultado de evaluar la expresión 2: " ++ show result