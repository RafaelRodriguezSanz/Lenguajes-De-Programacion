module SchemyInterpreter where

data SchemyExp
    = SchemyNumber Double
    | SchemyAdd SchemyExp SchemyExp
    | SchemyMult SchemyExp SchemyExp
    deriving (Eq)

eval :: SchemyExp -> Double
eval (SchemyNumber n) = n
eval (SchemyAdd a b) = eval a + eval b
eval (SchemyMult a b) = eval a * eval b

instance Show SchemyExp where
    show (SchemyNumber n) = show n 
    show (SchemyAdd a b) = "(" ++ show a ++ ")" ++ " + " ++ "(" ++ show b ++ ")" 
    show (SchemyMult c d) = "(" ++ show c ++  ")" ++ " * " ++ "(" ++ show d ++ ")" 