
pub mod pile {
    
    use crate::operator::operator::{Operator, Operable};
    //use crate::method::{Method, ZeroaryMethod, UnaryMethod};

    pub struct Pile {
        data: Vec<f64>,
    }

    impl Pile {
        pub fn new() -> Pile {
            Pile {
                data: Vec::<f64>::new(),
            }
        }

        pub fn push(&mut self, valor: f64) {
            self.data.push(valor);
        }

        pub fn pop(&mut self)  -> Option<f64> {
            return self.data.pop();
        }
        
        pub fn to_string(&self) -> String {
            format!("{:?}", self.data)
        }

        pub fn operate(&mut self, operator: Operator) {
            match operator {
                Operator::Zeroary(zeroary_op) => {
                    let result = zeroary_op.operate(None, None);
                    self.push(result);
                },
                Operator::Unary(unary_op) => {
                    let value = self.pop().unwrap();
                    let result = unary_op.operate(Some(value), None);
                    self.push(result);
                }
                Operator::Binary(binary_op) => {
                    let last_operand = self.pop().unwrap();
                    let first_operand = self.pop().unwrap();
                    let result = binary_op.operate(Some(first_operand), Some(last_operand));
                    self.push(result);
                }
            }
        }  

        //pub fn method(&mut self, method: Method, pile: &Vec<f64>, variables: &Vec<f64>) {
        //    match method {
        //        Method::ZeroaryMethod(zeroary_mth) => {
        //            match zeroary_mth {
        //                Method::ZeroaryMethod::DUP => {
        //                    let result = zeroary_mth.method(None, pile);
        //                    self.push(result);
        //                }
        //                Method::ZeroaryMethod::POP => {
        //                    let result = zeroary_mth.method(None, pile);
        //                }
        //            }
        //        }
        //        Method::UnaryMethod(unary_mth) => {
        //            match unary_mth {
        //                Method::UnaryMethod::SET => {
        //                    let result = unary_mth.method(variables, pile);
        //                    self.push(result);
        //                }
        //                Method::UnaryMethod::GET => {
        //                    let result = unary_mth.method(variables, pile);
        //                }
        //            }
        //        }
        //    }
        //}

    }
}

pub use self::pile::Pile;
