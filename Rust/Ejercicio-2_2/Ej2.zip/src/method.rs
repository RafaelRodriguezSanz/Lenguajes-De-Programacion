//pub mod method {
//    use std::fmt;
//
//    pub enum ZeroaryMethod {
//        DUP,
//        POP,
//    }
//
//    pub enum UnaryMethod {
//        GET,
//        SET,
//    }
//
//    impl std::fmt::Display for ZeroaryMethod {
//        fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
//            match self {
//                ZeroaryMethod::DUP => write!(f, "DUP"),
//                ZeroaryMethod::POP => write!(f, "POP"),
//            }
//        }
//    }
//
//    impl std::fmt::Display for UnaryMethod {
//        fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
//            match self {
//                UnaryMethod::GET => write!(f, "GET"),
//                UnaryMethod::SET => write!(f, "SET"),
//            }
//        }
//    }
//
//    pub trait Methodable {
//        fn method(&self, pile: &mut Vec<f64>, memory: &mut Vec<f64>) -> f64;
//    }
//
//    impl Methodable for ZeroaryMethod {
//        fn method(&self, pile: &mut Vec<f64>, _memory: &mut Vec<f64>) -> f64 {
//            match self {
//                ZeroaryMethod::DUP => {
//                    let last = pile.last().cloned().unwrap() ;
//                    pile.push(last);
//                    return last;
//                }
//                ZeroaryMethod::POP => {
//                    return pile.pop().unwrap();
//                }
//            }
//        }
//    }
//
//    impl Methodable for UnaryMethod {
//        fn method(&self, pile: &mut Vec<f64>, memory: &mut Vec<f64>) -> f64 {
//            match self {
//                UnaryMethod::GET => {
//                    if let Some(index) = pile.pop() {
//                        if let Some(value) = memory.get(index as usize).cloned() {
//                            pile.push(value);
//                        }
//                    }
//                }
//                UnaryMethod::SET => {
//                    if let Some((index, value)) = pile.pop().zip(pile.pop()) {
//                        memory.insert(index as usize, value);
//                    }
//                }
//            }
//        }
//    }
//
//    pub enum Method {
//        Zeroary(ZeroaryMethod),
//        Unary(UnaryMethod),
//    }
//
//    impl Method {
//        pub fn method(&self, pile: &mut Vec<f64>, memory: &mut Vec<f64>) -> f64 {
//            match self {
//                Method::Zeroary(mth) => mth.method(pile, memory),
//                Method::Unary(mth) => mth.method(pile, memory),
//            }
//        }
//
//        pub fn to_string(&self) -> String {
//            match self {
//                Method::Zeroary(mth) => mth.to_string(),
//                Method::Unary(mth) => mth.to_string(),
//            }
//        }
//
//        pub fn values() -> Vec<String> {
//            let zeroary_values: Vec<String> = vec![
//                ZeroaryMethod::DUP.to_string(),
//                ZeroaryMethod::POP.to_string(),
//            ];
//            let unary_values: Vec<String> = vec![
//                UnaryMethod::GET.to_string(),
//                UnaryMethod::SET.to_string(),
//            ];
//
//            zeroary_values.into_iter().chain(unary_values).collect()
//        }
//    }
//}
//
//pub use method::{Method, ZeroaryMethod, UnaryMethod};
//