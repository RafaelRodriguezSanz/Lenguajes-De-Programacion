use rand::Rng;

fn main() {
    let mut rng = rand::thread_rng();
    println!("Dado 1: {}", rng.gen_range(1..7));
    println!("Dado 2: {}", rng.gen_range(1..7));
}