const StatusEnum = {
    FULFILLED: 'fulfilled',
    REJECTED: 'rejected',
};

module.exports = {StatusEnum};