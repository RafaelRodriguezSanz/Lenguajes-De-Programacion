class Punto {
    constructor(...coordenadas) {
      this.coordenadas = coordenadas;
    }
  }
  
module.exports = Punto;